<?php
// Basic PHP header to ensure proper handling
header("Content-Type: text/html; charset=UTF-8");
?>
<!DOCTYPE html>
<html lang="hi">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ग्राम पंचायत चिखली - तालुका कुरखेडा जिल्हा गडचिरोली</title>
  
  <!-- CSS Libraries -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css">
  
  <style>
    :root {
      --primary-color: #008000; /* Green */
      --secondary-color: #b30000; /* Dark Red */
      --accent-color: #ff9900; /* Orange */
      --light-color: #ffffff; /* White */
      --dark-color: #333333; /* Dark Gray */
      --gray-color: #f5f5f5; /* Light Gray */
    }
    
    body {
      font-family: 'Arial', sans-serif;
      line-height: 1.6;
      color: var(--dark-color);
    }
    
    /* Header Styles */
    .top-header {
      background-color: var(--primary-color);
      color: var(--light-color);
    }
    
    .logo-text {
      font-size: 1.3rem;
      font-weight: bold;
    }
    
    .main-nav {
      background-color: var(--secondary-color);
    }
    
    .main-nav .nav-link {
      color: var(--light-color) !important;
      font-weight: 500;
      padding: 0.8rem 1rem;
    }
    
    .main-nav .nav-link:hover {
      background-color: rgba(0, 0, 0, 0.2);
    }
    
    /* Hero Slider */
    .hero-slider {
      height: 500px;
    }
    
    .swiper-slide img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    
    /* Service Links */
    .service-section {
      background-color: var(--gray-color);
      padding: 3rem 0;
    }
    
    .service-card {
      text-align: center;
      background-color: var(--light-color);
      border-radius: 10px;
      padding: 1.5rem;
      margin-bottom: 1.5rem;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease;
    }
    
    .service-card:hover {
      transform: translateY(-5px);
    }
    
    .service-icon {
      font-size: 2.5rem;
      color: var(--primary-color);
      margin-bottom: 1rem;
    }
    
    /* Notice Board */
    .notice-item {
      border-left: 4px solid var(--accent-color);
      margin-bottom: 1rem;
      padding: 1rem;
      background-color: var(--light-color);
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
    }
    
    /* Projects & Schemes */
    .card-img-top {
      height: 180px;
      object-fit: cover;
    }
    
    .progress {
      height: 10px;
    }
    
    /* Contact Section */
    .contact-info {
      background-color: var(--gray-color);
      padding: 2rem;
      border-radius: 10px;
    }
    
    .contact-section {
      background-color: var(--primary-color);
      color: var(--light-color);
      padding: 3rem 0;
    }

    /* Footer */
    footer {
      background-color: var(--secondary-color);
      color: var(--light-color);
      padding: 2rem 0;
    }
    
    /* Login Modal */
    .auth-modal .modal-header {
      background-color: var(--primary-color);
      color: var(--light-color);
    }

    /* Authentication Page */
    .auth-container {
      min-height: 80vh;
      display: flex;
    }
    
    .auth-form-side {
      background-color: var(--light-color);
      padding: 2rem;
    }
    
    .auth-hero-side {
      background-color: var(--primary-color);
      color: var(--light-color);
      padding: 2rem;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    
    /* Responsive */
    @media (max-width: 768px) {
      .logo-text {
        font-size: 1rem;
      }
      
      .hero-slider {
        height: 300px;
      }
      
      .auth-container {
        flex-direction: column;
      }
    }

    /* Animation for notices */
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    
    .animated-item {
      animation: fadeIn 0.5s ease forwards;
      opacity: 0;
    }
    
    .animated-item:nth-child(1) { animation-delay: 0.1s; }
    .animated-item:nth-child(2) { animation-delay: 0.2s; }
    .animated-item:nth-child(3) { animation-delay: 0.3s; }
    .animated-item:nth-child(4) { animation-delay: 0.4s; }
    .animated-item:nth-child(5) { animation-delay: 0.5s; }

    /* Meeting Calendar */
    .meeting-date {
      width: 70px;
      height: 70px;
      background-color: var(--secondary-color);
      color: var(--light-color);
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      border-radius: 5px;
    }
    
    .meeting-day {
      font-size: 1.5rem;
      font-weight: bold;
    }
    
    .meeting-month {
      font-size: 0.8rem;
      text-transform: uppercase;
    }
  </style>
</head>
<body>
  <!-- Login/Register Modal -->
  <div class="modal fade auth-modal" id="authModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="authModalLabel">लॉग इन / रजिस्टर</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <ul class="nav nav-tabs" id="authTab" role="tablist">
            <li class="nav-item" role="presentation">
              <button class="nav-link active" id="login-tab" data-bs-toggle="tab" data-bs-target="#login-tab-pane" type="button" role="tab" aria-controls="login-tab-pane" aria-selected="true">लॉग इन</button>
            </li>
            <li class="nav-item" role="presentation">
              <button class="nav-link" id="register-tab" data-bs-toggle="tab" data-bs-target="#register-tab-pane" type="button" role="tab" aria-controls="register-tab-pane" aria-selected="false">रजिस्टर</button>
            </li>
          </ul>
          <div class="tab-content pt-3" id="authTabContent">
            <div class="tab-pane fade show active" id="login-tab-pane" role="tabpanel" aria-labelledby="login-tab" tabindex="0">
              <!-- Login Form -->
              <form id="loginForm">
                <div class="mb-3">
                  <label for="loginUsername" class="form-label">उपयोगकर्ता नाम</label>
                  <input type="text" class="form-control" id="loginUsername" required>
                </div>
                <div class="mb-3">
                  <label for="loginPassword" class="form-label">पासवर्ड</label>
                  <input type="password" class="form-control" id="loginPassword" required>
                </div>
                <button type="submit" class="btn btn-success w-100">लॉग इन</button>
              </form>
            </div>
            <div class="tab-pane fade" id="register-tab-pane" role="tabpanel" aria-labelledby="register-tab" tabindex="0">
              <!-- Register Form -->
              <form id="registerForm">
                <div class="mb-3">
                  <label for="registerFullName" class="form-label">पूरा नाम</label>
                  <input type="text" class="form-control" id="registerFullName" required>
                </div>
                <div class="mb-3">
                  <label for="registerUsername" class="form-label">उपयोगकर्ता नाम</label>
                  <input type="text" class="form-control" id="registerUsername" required>
                </div>
                <div class="mb-3">
                  <label for="registerEmail" class="form-label">ईमेल</label>
                  <input type="email" class="form-control" id="registerEmail" required>
                </div>
                <div class="mb-3">
                  <label for="registerPhone" class="form-label">फोन नंबर</label>
                  <input type="tel" class="form-control" id="registerPhone" required>
                </div>
                <div class="mb-3">
                  <label for="registerVillage" class="form-label">गांव</label>
                  <input type="text" class="form-control" id="registerVillage" value="चिखली" required>
                </div>
                <div class="mb-3">
                  <label for="registerPassword" class="form-label">पासवर्ड</label>
                  <input type="password" class="form-control" id="registerPassword" required>
                </div>
                <button type="submit" class="btn btn-success w-100">रजिस्टर</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <!-- Header -->
  <header>
    <div class="top-header py-2">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-6 text-center text-md-start">
            <div class="logo-text">ग्रामपंचायत चिखली तालुका कुरखेडा जिल्हा गडचिरोली</div>
          </div>
          <div class="col-md-6 text-center text-md-end">
            <button class="btn btn-outline-light btn-sm" data-bs-toggle="modal" data-bs-target="#authModal">
              <i class="fas fa-user me-1"></i> लॉग इन / रजिस्टर
            </button>
          </div>
        </div>
      </div>
    </div>
    <nav class="navbar navbar-expand-lg main-nav">
      <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav mx-auto">
            <li class="nav-item">
              <a class="nav-link active" href="#home">मुख्य पृष्ठ</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#about">परिचय</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#services">सेवाएं</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#notices">सूचनाएं</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#schemes">योजनाएं</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#projects">प्रोजेक्ट्स</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#meetings">बैठकें</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#contact">संपर्क</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>
  
  <!-- Hero Slider -->
  <section id="home" class="hero-slider">
    <div class="swiper mySwiper">
      <div class="swiper-wrapper">
        <div class="swiper-slide">
          <img src="./assets/images/photo.jpeg" alt="Gram Panchayat Office">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/photo2.jpeg" alt="Village Road">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/photo3.jpeg" alt="Community Water System">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/photo4.jpeg" alt="Village Meeting">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/photo5.jpeg" alt="Farm Land">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/photo7.jpeg" alt="Solar Street Light">
        </div>
        <div class="swiper-slide">
          <img src="./assets/images/photo8.jpeg" alt="Village School">
        </div>
      </div>
      <div class="swiper-pagination"></div>
    </div>
  </section>
  
  <!-- About Section -->
  <section id="about" class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <h2 class="mb-4">ग्राम पंचायत चिखली का परिचय</h2>
          <p>ग्राम पंचायत चिखली तालुका कुरखेडा जिल्हा गडचिरोली में स्थित है। यह एक समृद्ध सांस्कृतिक और कृषि परंपराओं वाला गांव है। हमारी पंचायत का उद्देश्य अपने नागरिकों को उत्कृष्ट सेवाएं प्रदान करना और ग्रामीण विकास को बढ़ावा देना है।</p>
          <p>हमारी पंचायत में विभिन्न समितियां और स्व-सहायता समूह सक्रिय हैं जो ग्रामीण विकास और समृद्धि के लिए कार्य करते हैं। हम अपने गांव को डिजिटल रूप से सशक्त और आत्मनिर्भर बनाने के लिए प्रतिबद्ध हैं।</p>
        </div>
        <div class="col-lg-6">
          <div class="ratio ratio-16x9">
            <iframe src="https://www.youtube.com/embed/dQw4w9WgXcQ" title="Gram Panchayat Chikhali Introduction" allowfullscreen></iframe>
          </div>
          <div class="mt-4">
            <div class="ratio ratio-16x9">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29919.565319444238!2d80.01889242748945!3d20.164806925344787!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a2c5d741fad3aed%3A0xabf209d145b1057!2sChikhali%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1634913547294!5m2!1sen!2sin" allowfullscreen="" loading="lazy"></iframe>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <!-- Service Links -->
  <section id="services" class="service-section">
    <div class="container">
      <h2 class="text-center mb-5">हमारी सेवाएं</h2>
      <div class="row">
        <div class="col-md-4 col-sm-6 animated-item">
          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-id-card"></i>
            </div>
            <h4>जन्म/मृत्यु प्रमाण पत्र</h4>
            <p>जन्म और मृत्यु प्रमाण पत्र के लिए ऑनलाइन आवेदन करें।</p>
            <a href="https://crsorgi.gov.in/web/index.php/auth/login" class="btn btn-outline-success mt-2" target="_blank">अभी आवेदन करें</a>
          </div>
        </div>
        
        <div class="col-md-4 col-sm-6 animated-item">
          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-laptop-house"></i>
            </div>
            <h4>महाराष्ट्र ई-सेवाएं</h4>
            <p>सभी महाराष्ट्र सरकार की ऑनलाइन सेवाओं तक एकल पहुंच।</p>
            <a href="https://mahaegram.co.in/" class="btn btn-outline-success mt-2" target="_blank">सेवाएं देखें</a>
          </div>
        </div>
        
        <div class="col-md-4 col-sm-6 animated-item">
          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-briefcase"></i>
            </div>
            <h4>MGNREGA</h4>
            <p>महात्मा गांधी राष्ट्रीय ग्रामीण रोजगार गारंटी अधिनियम।</p>
            <a href="https://nrega.nic.in/netnrega/home.aspx" class="btn btn-outline-success mt-2" target="_blank">जॉब कार्ड देखें</a>
          </div>
        </div>
        
        <div class="col-md-4 col-sm-6 animated-item">
          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-wheelchair"></i>
            </div>
            <h4>दिव्यांग साथी</h4>
            <p>दिव्यांग व्यक्तियों के लिए सहायता और कल्याण योजनाएं।</p>
            <a href="https://www.swavlambancard.gov.in/" class="btn btn-outline-success mt-2" target="_blank">अधिक जानकारी</a>
          </div>
        </div>
        
        <div class="col-md-4 col-sm-6 animated-item">
          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-university"></i>
            </div>
            <h4>सरकारी सेवाएं</h4>
            <p>आम नागरिकों के लिए सभी सरकारी सेवाओं तक पहुंच।</p>
            <a href="https://www.india.gov.in/" class="btn btn-outline-success mt-2" target="_blank">सेवाएं देखें</a>
          </div>
        </div>
        
        <div class="col-md-4 col-sm-6 animated-item">
          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-vote-yea"></i>
            </div>
            <h4>मतदाता सेवाएं</h4>
            <p>मतदाता पहचान पत्र और मतदाता सूची से संबंधित सेवाएं।</p>
            <a href="https://voters.eci.gov.in/" class="btn btn-outline-success mt-2" target="_blank">सेवाएं देखें</a>
          </div>
        </div>
        
        <div class="col-md-4 col-sm-6 animated-item">
          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-desktop"></i>
            </div>
            <h4>CSC सेवाएं</h4>
            <p>कॉमन सर्विस सेंटर के माध्यम से उपलब्ध सभी सेवाएं।</p>
            <a href="https://digitalseva.csc.gov.in/" class="btn btn-outline-success mt-2" target="_blank">सेवाएं देखें</a>
          </div>
        </div>
        
        <div class="col-md-4 col-sm-6 animated-item">
          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-fingerprint"></i>
            </div>
            <h4>UIDAI सेवाएं</h4>
            <p>आधार कार्ड से संबंधित सभी सेवाएं और अपडेट्स।</p>
            <a href="https://uidai.gov.in/" class="btn btn-outline-success mt-2" target="_blank">सेवाएं देखें</a>
          </div>
        </div>
        
        <div class="col-md-4 col-sm-6 animated-item">
          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-building"></i>
            </div>
            <h4>eGramSwaraj</h4>
            <p>ग्राम पंचायतों के लिए ई-गवर्नेंस एप्लिकेशन।</p>
            <a href="https://egramswaraj.gov.in/" class="btn btn-outline-success mt-2" target="_blank">लॉगिन करें</a>
          </div>
        </div>
        
        <div class="col-md-4 col-sm-6 animated-item">
          <div class="service-card">
            <div class="service-icon">
              <i class="fas fa-home"></i>
            </div>
            <h4>प्रधानमंत्री आवास योजना</h4>
            <p>सभी के लिए आवास योजना की जानकारी और आवेदन।</p>
            <a href="https://rhreporting.nic.in/netiay/ConvergenceReport/HouseSanctionedVsWorkCreatedReport.aspx" class="btn btn-outline-success mt-2" target="_blank">स्थिति जांचें</a>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <!-- Notices Section -->
  <section id="notices" class="py-5">
    <div class="container">
      <h2 class="text-center mb-5">सूचना पट्ट</h2>
      <div class="row">
        <div class="col-lg-8 mx-auto">
          <div id="noticesContainer">
            <!-- Notices will be loaded dynamically -->
            <div class="text-center">
              <div class="spinner-border text-success" role="status">
                <span class="visually-hidden">Loading...</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <!-- Schemes Section -->
  <section id="schemes" class="py-5 bg-light">
    <div class="container">
      <h2 class="text-center mb-5">कल्याणकारी योजनाएं</h2>
      <div class="row" id="schemesContainer">
        <!-- Schemes will be loaded dynamically -->
        <div class="text-center">
          <div class="spinner-border text-success" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <!-- Projects Section -->
  <section id="projects" class="py-5">
    <div class="container">
      <h2 class="text-center mb-5">विकास प्रोजेक्ट्स</h2>
      <div class="row" id="projectsContainer">
        <!-- Projects will be loaded dynamically -->
        <div class="text-center">
          <div class="spinner-border text-success" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <!-- Meetings Section -->
  <section id="meetings" class="py-5 bg-light">
    <div class="container">
      <h2 class="text-center mb-5">आगामी बैठकें और कार्यक्रम</h2>
      <div class="row" id="meetingsContainer">
        <!-- Meetings will be loaded dynamically -->
        <div class="text-center">
          <div class="spinner-border text-success" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <!-- Contact Section -->
  <section id="contact" class="contact-section py-5">
    <div class="container">
      <h2 class="text-center mb-5">संपर्क करें</h2>
      <div class="row">
        <div class="col-md-6 mb-4">
          <div class="contact-info">
            <h4>संपर्क विवरण</h4>
            <p><i class="fas fa-map-marker-alt me-2"></i> ग्राम पंचायत कार्यालय, चिखली, तालुका कुरखेडा जिल्हा गडचिरोली पिन कोड ४४१२०९</p>
            <hr>
            <h5>महत्वपूर्ण संपर्क नंबर:</h5>
            <p><i class="fas fa-user me-2"></i> संगणक चालक: <a href="tel:7517654904" class="text-dark">7517654904</a></p>
            <p><i class="fas fa-user me-2"></i> सरपंच: <a href="tel:8554800181" class="text-dark">8554800181</a></p>
            <p><i class="fas fa-user me-2"></i> उपसरपंच: <a href="tel:9420976688" class="text-dark">9420976688</a></p>
            <p><i class="fas fa-user me-2"></i> ग्रामसेवक: <a href="tel:9511745767" class="text-dark">9511745767</a></p>
            <p><i class="fas fa-user me-2"></i> ग्रामपरिचर: <a href="tel:7888192654" class="text-dark">7888192654</a></p>
            <p><i class="fas fa-user me-2"></i> रोजगार सेवक: <a href="tel:7721856406" class="text-dark">7721856406</a></p>
          </div>
        </div>
        <div class="col-md-6">
          <div class="card">
            <div class="card-body">
              <h4 class="card-title mb-4">हमें संदेश भेजें</h4>
              <form id="contactForm">
                <div class="mb-3">
                  <label for="name" class="form-label">नाम</label>
                  <input type="text" class="form-control" id="name" required>
                </div>
                <div class="mb-3">
                  <label for="email" class="form-label">ईमेल</label>
                  <input type="email" class="form-control" id="email" required>
                </div>
                <div class="mb-3">
                  <label for="phone" class="form-label">फोन नंबर</label>
                  <input type="tel" class="form-control" id="phone">
                </div>
                <div class="mb-3">
                  <label for="message" class="form-label">संदेश</label>
                  <textarea class="form-control" id="message" rows="4" required></textarea>
                </div>
                <button type="submit" class="btn btn-light">संदेश भेजें</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <!-- Footer -->
  <footer class="text-center">
    <div class="container py-4">
      <p>© 2023 ग्राम पंचायत चिखली. सर्वाधिकार सुरक्षित.</p>
      <p>तालुका कुरखेडा जिल्हा गडचिरोली पिन कोड ४४१२०९</p>
    </div>
  </footer>
  
  <!-- JavaScript Libraries -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
  
  <script>
    // Initialize Swiper
    var swiper = new Swiper(".mySwiper", {
      slidesPerView: 1,
      spaceBetween: 30,
      loop: true,
      autoplay: {
        delay: 3000,
        disableOnInteraction: false,
      },
      pagination: {
        el: ".swiper-pagination",
        clickable: true,
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
    });
    
    // Load notices directly from PHP
    <?php
    // Get data from PHP files to avoid JSON file access issues
    require_once('api/notices.php');
    echo "const noticesData = " . json_encode($notices) . ";\n";
    echo "loadNotices(noticesData);\n";
    
    require_once('api/schemes.php');
    echo "const schemesData = " . json_encode($schemes) . ";\n";
    echo "loadSchemes(schemesData);\n";
    
    require_once('api/projects.php');
    echo "const projectsData = " . json_encode($projects) . ";\n";
    echo "loadProjects(projectsData);\n";
    
    require_once('api/meetings.php');
    echo "const meetingsData = " . json_encode($meetings) . ";\n";
    echo "loadMeetings(meetingsData);\n";
    ?>
    
    function loadNotices(data) {
      const noticesContainer = document.getElementById('noticesContainer');
      noticesContainer.innerHTML = '';
      
      data.forEach(notice => {
        const noticeDate = new Date(notice.date);
        const formattedDate = noticeDate.toLocaleDateString('hi-IN', {
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        });
        
        const noticeHtml = `
          <div class="notice-item animated-item">
            <div class="d-flex align-items-center mb-2">
              <i class="${notice.iconClass} me-2"></i>
              <h5 class="mb-0">${notice.title.hi}</h5>
            </div>
            <p>${notice.content.hi}</p>
            <small class="text-muted">प्रकाशित: ${formattedDate}</small>
          </div>
        `;
        
        noticesContainer.innerHTML += noticeHtml;
      });
    }
    
    function loadSchemes(data) {
      const schemesContainer = document.getElementById('schemesContainer');
      schemesContainer.innerHTML = '';
      
      data.forEach(scheme => {
        const schemeHtml = `
          <div class="col-lg-4 col-md-6 mb-4 animated-item">
            <div class="card h-100">
              <img src="${scheme.imageUrl}" class="card-img-top" alt="${scheme.title.hi}">
              <div class="card-body">
                <h5 class="card-title">${scheme.title.hi}</h5>
                <p class="card-text">${scheme.description.hi}</p>
              </div>
              <div class="card-footer bg-transparent border-top-0">
                <button class="btn btn-outline-success btn-sm">अधिक जानकारी</button>
              </div>
            </div>
          </div>
        `;
        
        schemesContainer.innerHTML += schemeHtml;
      });
    }
    
    function loadProjects(data) {
      const projectsContainer = document.getElementById('projectsContainer');
      projectsContainer.innerHTML = '';
      
      data.forEach(project => {
        let statusText = '';
        let statusClass = '';
        
        switch(project.status) {
          case 'completed':
            statusText = 'पूर्ण';
            statusClass = 'bg-success';
            break;
          case 'in-progress':
            statusText = 'प्रगति पर';
            statusClass = 'bg-warning';
            break;
          case 'upcoming':
            statusText = 'आगामी';
            statusClass = 'bg-info';
            break;
        }
        
        const projectHtml = `
          <div class="col-lg-6 mb-4 animated-item">
            <div class="card h-100">
              <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                  <h5 class="card-title mb-0">${project.title.hi}</h5>
                  <span class="badge ${statusClass}">${statusText}</span>
                </div>
                <p class="card-text">${project.description.hi}</p>
                <div class="row mb-3">
                  <div class="col-6">
                    <small class="text-muted">बजट:</small>
                    <p class="mb-0">${project.budget}</p>
                  </div>
                  <div class="col-6">
                    <small class="text-muted">पूर्णता तिथि:</small>
                    <p class="mb-0">${project.completionDate}</p>
                  </div>
                </div>
                <div>
                  <small class="text-muted">प्रगति:</small>
                  <div class="progress">
                    <div class="progress-bar bg-success" role="progressbar" style="width: ${project.progress}%" aria-valuenow="${project.progress}" aria-valuemin="0" aria-valuemax="100">${project.progress}%</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        `;
        
        projectsContainer.innerHTML += projectHtml;
      });
    }
    
    function loadMeetings(data) {
      const meetingsContainer = document.getElementById('meetingsContainer');
      meetingsContainer.innerHTML = '';
      
      data.forEach(meeting => {
        const meetingHtml = `
          <div class="col-lg-6 mb-4 animated-item">
            <div class="card h-100">
              <div class="card-body">
                <div class="d-flex">
                  <div class="meeting-date me-3">
                    <span class="meeting-day">${meeting.day}</span>
                    <span class="meeting-month">${meeting.month.hi}</span>
                  </div>
                  <div>
                    <h5 class="card-title">${meeting.title.hi}</h5>
                    <p class="mb-1"><i class="far fa-clock me-2"></i> ${meeting.time.hi}</p>
                    <p class="mb-0"><i class="fas fa-map-marker-alt me-2"></i> ${meeting.venue.hi}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        `;
        
        meetingsContainer.innerHTML += meetingHtml;
      });
    }
    
    // Handle login form submission
    document.getElementById('loginForm').addEventListener('submit', function(e) {
      e.preventDefault();
      
      const username = document.getElementById('loginUsername').value;
      const password = document.getElementById('loginPassword').value;
      
      // Simulate login without AJAX (to avoid cross-domain issues)
      alert('लॉगिन सफल! स्वागत है, ' + username);
      
      // Hide the modal
      const authModal = bootstrap.Modal.getInstance(document.getElementById('authModal'));
      authModal.hide();
      
      // Update login button to show logged in state
      document.querySelector('.top-header .btn').innerHTML = '<i class="fas fa-user me-1"></i> ' + username;
    });
    
    // Handle register form submission
    document.getElementById('registerForm').addEventListener('submit', function(e) {
      e.preventDefault();
      
      const fullName = document.getElementById('registerFullName').value;
      
      // Simulate registration without AJAX (to avoid cross-domain issues)
      alert('पंजीकरण सफल! स्वागत है, ' + fullName);
      
      // Hide the modal
      const authModal = bootstrap.Modal.getInstance(document.getElementById('authModal'));
      authModal.hide();
      
      // Update login button to show logged in state
      document.querySelector('.top-header .btn').innerHTML = '<i class="fas fa-user me-1"></i> ' + fullName;
    });
    
    // Handle contact form submission
    document.getElementById('contactForm').addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Simulate form submission
      alert('आपका संदेश सफलतापूर्वक भेज दिया गया है। हम जल्द ही आपसे संपर्क करेंगे।');
      this.reset();
    });
  </script>
</body>
</html>