<?php
// Enable CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Get the notices data
$notices = [
  [
    "id" => 1,
    "title" => [
      "en" => "Gram Sabha Meeting on September 25, 2023",
      "hi" => "25 सितंबर, 2023 को ग्राम सभा बैठक"
    ],
    "content" => [
      "en" => "All villagers are requested to attend the Gram Sabha meeting on September 25, 2023 at 10:00 AM at the Panchayat Bhavan. Important issues regarding water supply and road construction will be discussed.",
      "hi" => "सभी ग्रामवासियों से अनुरोध है कि वे 25 सितंबर, 2023 को सुबह 10:00 बजे पंचायत भवन में ग्राम सभा बैठक में भाग लें। जल आपूर्ति और सड़क निर्माण से संबंधित महत्वपूर्ण मुद्दों पर चर्चा की जाएगी।"
    ],
    "date" => "2023-09-15",
    "iconClass" => "fa-solid fa-bullhorn text-red-600"
  ],
  [
    "id" => 2,
    "title" => [
      "en" => "Distribution of Seedlings for Kharif Season",
      "hi" => "खरीफ सीजन के लिए पौधों का वितरण"
    ],
    "content" => [
      "en" => "Free distribution of high-quality seedlings for rice, vegetables, and pulses will be held on August 10, 2023 at the Gram Panchayat office from 9 AM to 5 PM. Please bring your Aadhaar card and land documents.",
      "hi" => "10 अगस्त, 2023 को सुबह 9 बजे से शाम 5 बजे तक ग्राम पंचायत कार्यालय में चावल, सब्जियों और दालों के लिए उच्च गुणवत्ता वाले पौधों का मुफ्त वितरण किया जाएगा। कृपया अपना आधार कार्ड और जमीन के दस्तावेज लाएं।"
    ],
    "date" => "2023-08-01",
    "iconClass" => "fa-solid fa-seedling text-green-600"
  ],
  [
    "id" => 3,
    "title" => [
      "en" => "COVID-19 Vaccination Camp",
      "hi" => "कोविड-19 टीकाकरण शिविर"
    ],
    "content" => [
      "en" => "A special COVID-19 booster dose vaccination camp will be organized in the village on July 20, 2023. All eligible citizens above 18 years are requested to get vaccinated. Bring your vaccination certificate and ID proof.",
      "hi" => "20 जुलाई, 2023 को गांव में एक विशेष कोविड-19 बूस्टर डोज टीकाकरण शिविर का आयोजन किया जाएगा। 18 वर्ष से अधिक आयु के सभी पात्र नागरिकों से टीकाकरण कराने का अनुरोध है। अपना टीकाकरण प्रमाण पत्र और आईडी प्रूफ लाएं।"
    ],
    "date" => "2023-07-10",
    "iconClass" => "fa-solid fa-syringe text-blue-600"
  ],
  [
    "id" => 4,
    "title" => [
      "en" => "Electricity Supply Interruption Notice",
      "hi" => "बिजली आपूर्ति बाधित होने की सूचना"
    ],
    "content" => [
      "en" => "Due to maintenance work on the main transmission line, electricity supply will be interrupted on June 15, 2023 from 10:00 AM to 4:00 PM. We apologize for the inconvenience caused.",
      "hi" => "मुख्य ट्रांसमिशन लाइन पर रखरखाव कार्य के कारण 15 जून, 2023 को सुबह 10:00 बजे से शाम 4:00 बजे तक बिजली आपूर्ति में बाधा आएगी। असुविधा के लिए हमें खेद है।"
    ],
    "date" => "2023-06-10",
    "iconClass" => "fa-solid fa-bolt text-yellow-600"
  ],
  [
    "id" => 5,
    "title" => [
      "en" => "Ration Card Update Camp",
      "hi" => "राशन कार्ड अपडेट शिविर"
    ],
    "content" => [
      "en" => "A special camp for updating ration cards will be held at the Gram Panchayat office on May 25-26, 2023. Please bring all necessary documents including Aadhaar card, income certificate, and existing ration card (if any).",
      "hi" => "25-26 मई, 2023 को ग्राम पंचायत कार्यालय में राशन कार्ड अपडेट करने के लिए एक विशेष शिविर का आयोजन किया जाएगा। कृपया आधार कार्ड, आय प्रमाण पत्र और मौजूदा राशन कार्ड (यदि कोई हो) सहित सभी आवश्यक दस्तावेज लाएं।"
    ],
    "date" => "2023-05-15",
    "iconClass" => "fa-solid fa-id-card text-purple-600"
  ]
];

// Output as JSON
echo json_encode($notices);
?>