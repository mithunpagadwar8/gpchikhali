<?php
// Enable CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// For demo purposes, returning a mock user response
$response = [
  "id" => 1,
  "username" => "user123",
  "fullName" => "Demo User",
  "email" => "user@example.com",
  "phone" => "9876543210",
  "village" => "Chikhali",
  "role" => "citizen"
];

echo json_encode($response);
?>