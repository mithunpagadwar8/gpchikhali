<?php
// Enable CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Get the projects data
$projects = [
  [
    "id" => 1,
    "title" => [
      "en" => "Main Village Road Construction",
      "hi" => "मुख्य गांव सड़क निर्माण"
    ],
    "description" => [
      "en" => "Construction of 3.5 km concrete road from village entrance to market area with proper drainage system.",
      "hi" => "गांव के प्रवेश द्वार से बाजार क्षेत्र तक 3.5 किलोमीटर कंक्रीट सड़क का उचित जल निकासी प्रणाली के साथ निर्माण।"
    ],
    "status" => "in-progress",
    "budget" => "₹75,00,000",
    "completionDate" => "2023-12-30",
    "progress" => 65
  ],
  [
    "id" => 2,
    "title" => [
      "en" => "Community Water Purification Plant",
      "hi" => "सामुदायिक जल शुद्धिकरण संयंत्र"
    ],
    "description" => [
      "en" => "Installation of RO water purification plant with 5000L capacity to provide clean drinking water to all households.",
      "hi" => "सभी घरों को स्वच्छ पेयजल प्रदान करने के लिए 5000L क्षमता वाले RO जल शुद्धिकरण संयंत्र की स्थापना।"
    ],
    "status" => "completed",
    "budget" => "₹15,00,000",
    "completionDate" => "2023-06-15",
    "progress" => 100
  ],
  [
    "id" => 3,
    "title" => [
      "en" => "Solar Street Lighting Project",
      "hi" => "सौर स्ट्रीट लाइटिंग प्रोजेक्ट"
    ],
    "description" => [
      "en" => "Installation of 75 solar-powered LED street lights covering all major roads and public spaces in the village.",
      "hi" => "गांव के सभी प्रमुख सड़कों और सार्वजनिक स्थानों को कवर करते हुए 75 सोलर-पावर्ड एलईडी स्ट्रीट लाइट्स की स्थापना।"
    ],
    "status" => "in-progress",
    "budget" => "₹18,50,000",
    "completionDate" => "2023-11-30",
    "progress" => 80
  ],
  [
    "id" => 4,
    "title" => [
      "en" => "Primary School Renovation",
      "hi" => "प्राथमिक स्कूल नवीनीकरण"
    ],
    "description" => [
      "en" => "Complete renovation of village primary school including new classrooms, toilets, computer lab and playground equipment.",
      "hi" => "गांव के प्राथमिक स्कूल का पूर्ण नवीनीकरण जिसमें नए कक्षाएं, शौचालय, कंप्यूटर लैब और खेल का मैदान उपकरण शामिल हैं।"
    ],
    "status" => "completed",
    "budget" => "₹22,00,000",
    "completionDate" => "2023-04-10",
    "progress" => 100
  ],
  [
    "id" => 5,
    "title" => [
      "en" => "Primary Health Center Upgrade",
      "hi" => "प्राथमिक स्वास्थ्य केंद्र अपग्रेड"
    ],
    "description" => [
      "en" => "Expansion and modernization of the village health center with new medical equipment, furniture, and essential medicine stocks.",
      "hi" => "नए चिकित्सा उपकरण, फर्नीचर और आवश्यक दवा स्टॉक के साथ गांव के स्वास्थ्य केंद्र का विस्तार और आधुनिकीकरण।"
    ],
    "status" => "in-progress",
    "budget" => "₹35,00,000",
    "completionDate" => "2024-02-28",
    "progress" => 40
  ],
  [
    "id" => 6,
    "title" => [
      "en" => "Waste Management System",
      "hi" => "अपशिष्ट प्रबंधन प्रणाली"
    ],
    "description" => [
      "en" => "Implementation of door-to-door waste collection and segregation system, with composting facility for organic waste.",
      "hi" => "घर-घर कचरा संग्रह और पृथक्करण प्रणाली का कार्यान्वयन, जैविक कचरे के लिए कम्पोस्टिंग सुविधा के साथ।"
    ],
    "status" => "upcoming",
    "budget" => "₹12,00,000",
    "completionDate" => "2024-04-15",
    "progress" => 0
  ],
  [
    "id" => 7,
    "title" => [
      "en" => "Community Center Construction",
      "hi" => "सामुदायिक केंद्र निर्माण"
    ],
    "description" => [
      "en" => "Construction of multi-purpose community center for village gatherings, functions, training programs and emergency shelter.",
      "hi" => "गांव की सभाओं, समारोहों, प्रशिक्षण कार्यक्रमों और आपातकालीन आश्रय के लिए बहु-उद्देश्यीय सामुदायिक केंद्र का निर्माण।"
    ],
    "status" => "upcoming",
    "budget" => "₹45,00,000",
    "completionDate" => "2024-06-30",
    "progress" => 0
  ]
];

// Output as JSON
echo json_encode($projects);
?>