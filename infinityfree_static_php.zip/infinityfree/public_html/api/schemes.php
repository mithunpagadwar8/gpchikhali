<?php
// Enable CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Get the schemes data
$schemes = [
  [
    "id" => 1,
    "title" => [
      "en" => "Pradhan Mantri Awas Yojana",
      "hi" => "प्रधानमंत्री आवास योजना"
    ],
    "description" => [
      "en" => "Housing for all scheme providing financial assistance for construction of pucca houses for eligible rural households.",
      "hi" => "पात्र ग्रामीण परिवारों के लिए पक्के घरों के निर्माण हेतु वित्तीय सहायता प्रदान करने वाली सभी के लिए आवास योजना।"
    ],
    "imageUrl" => "https://cdn.dnaindia.com/sites/default/files/styles/full/public/2019/02/08/787221-pmayhomes-thinkstock-020419.jpg"
  ],
  [
    "id" => 2,
    "title" => [
      "en" => "Mahatma Gandhi National Rural Employment Guarantee Act",
      "hi" => "महात्मा गांधी राष्ट्रीय ग्रामीण रोजगार गारंटी अधिनियम"
    ],
    "description" => [
      "en" => "Guarantees 100 days of wage employment in a financial year to rural households whose adult members volunteer to do unskilled manual work.",
      "hi" => "ग्रामीण परिवारों को एक वित्तीय वर्ष में 100 दिनों के मजदूरी रोजगार की गारंटी देता है जिनके वयस्क सदस्य अकुशल मैनुअल कार्य करने के लिए स्वेच्छा से आगे आते हैं।"
    ],
    "imageUrl" => "https://assets.thehansindia.com/h-upload/2021/07/09/1600x960_1087569-nregs.jpg"
  ],
  [
    "id" => 3,
    "title" => [
      "en" => "National Social Assistance Program",
      "hi" => "राष्ट्रीय सामाजिक सहायता कार्यक्रम"
    ],
    "description" => [
      "en" => "Provides pension to elderly, widows and disabled persons and also includes benefit on death of primary breadwinner to the bereaved household.",
      "hi" => "बुजुर्गों, विधवाओं और दिव्यांग व्यक्तियों को पेंशन प्रदान करता है और मुख्य कमाने वाले की मृत्यु पर शोकाकुल परिवार को लाभ भी शामिल है।"
    ],
    "imageUrl" => "https://www.hindikishan.com/wp-content/uploads/2020/07/old-age-pension-scheme-1.jpg"
  ],
  [
    "id" => 4,
    "title" => [
      "en" => "Pradhan Mantri Kisan Samman Nidhi",
      "hi" => "प्रधानमंत्री किसान सम्मान निधि"
    ],
    "description" => [
      "en" => "Income support scheme that provides ₹6,000 annually to all landholding farmer families in the country in three equal installments.",
      "hi" => "आय समर्थन योजना जो देश के सभी भूमि धारक किसान परिवारों को तीन समान किस्तों में सालाना ₹6,000 प्रदान करती है।"
    ],
    "imageUrl" => "https://www.bvnews.in/wp-content/uploads/2020/01/PM-Kisan-Samman-Nidhi-Yojana.jpg"
  ],
  [
    "id" => 5,
    "title" => [
      "en" => "Swachh Bharat Mission (Gramin)",
      "hi" => "स्वच्छ भारत मिशन (ग्रामीण)"
    ],
    "description" => [
      "en" => "Program aimed at improving the levels of cleanliness in rural areas through solid and liquid waste management and making villages Open Defecation Free (ODF).",
      "hi" => "ठोस और तरल अपशिष्ट प्रबंधन के माध्यम से ग्रामीण क्षेत्रों में स्वच्छता के स्तर में सुधार और गांवों को खुले में शौच से मुक्त (ODF) बनाने के उद्देश्य से कार्यक्रम।"
    ],
    "imageUrl" => "https://i0.wp.com/www.financialexpress.com/wp-content/uploads/2018/02/2-75.jpg"
  ]
];

// Output as JSON
echo json_encode($schemes);
?>