<?php
// Enable CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Get the meetings data
$meetings = [
  [
    "id" => 1,
    "title" => [
      "en" => "Gram Sabha Meeting",
      "hi" => "ग्राम सभा बैठक"
    ],
    "date" => "2023-10-15",
    "time" => [
      "en" => "10:00 AM",
      "hi" => "सुबह 10:00 बजे"
    ],
    "venue" => [
      "en" => "Panchayat Bhavan",
      "hi" => "पंचायत भवन"
    ],
    "month" => [
      "en" => "OCT",
      "hi" => "अक्टू"
    ],
    "day" => "15"
  ],
  [
    "id" => 2,
    "title" => [
      "en" => "Women's Self-Help Group Meeting",
      "hi" => "महिला स्वयं सहायता समूह की बैठक"
    ],
    "date" => "2023-10-10",
    "time" => [
      "en" => "2:00 PM",
      "hi" => "दोपहर 2:00 बजे"
    ],
    "venue" => [
      "en" => "Community Hall",
      "hi" => "सामुदायिक हॉल"
    ],
    "month" => [
      "en" => "OCT",
      "hi" => "अक्टू"
    ],
    "day" => "10"
  ],
  [
    "id" => 3,
    "title" => [
      "en" => "Farmers' Training Program",
      "hi" => "किसान प्रशिक्षण कार्यक्रम"
    ],
    "date" => "2023-10-18",
    "time" => [
      "en" => "11:00 AM",
      "hi" => "सुबह 11:00 बजे"
    ],
    "venue" => [
      "en" => "Agriculture Extension Center",
      "hi" => "कृषि विस्तार केंद्र"
    ],
    "month" => [
      "en" => "OCT",
      "hi" => "अक्टू"
    ],
    "day" => "18"
  ],
  [
    "id" => 4,
    "title" => [
      "en" => "Village Development Committee Meeting",
      "hi" => "ग्राम विकास समिति की बैठक"
    ],
    "date" => "2023-10-22",
    "time" => [
      "en" => "4:00 PM",
      "hi" => "शाम 4:00 बजे"
    ],
    "venue" => [
      "en" => "Panchayat Office",
      "hi" => "पंचायत कार्यालय"
    ],
    "month" => [
      "en" => "OCT",
      "hi" => "अक्टू"
    ],
    "day" => "22"
  ],
  [
    "id" => 5,
    "title" => [
      "en" => "Health Awareness Camp",
      "hi" => "स्वास्थ्य जागरूकता शिविर"
    ],
    "date" => "2023-10-28",
    "time" => [
      "en" => "9:00 AM",
      "hi" => "सुबह 9:00 बजे"
    ],
    "venue" => [
      "en" => "Primary Health Center",
      "hi" => "प्राथमिक स्वास्थ्य केंद्र"
    ],
    "month" => [
      "en" => "OCT",
      "hi" => "अक्टू"
    ],
    "day" => "28"
  ]
];

// Output as JSON
echo json_encode($meetings);
?>