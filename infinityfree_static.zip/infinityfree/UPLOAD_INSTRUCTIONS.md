# InfinityFree Upload Instructions

## Step 1: Sign Up for InfinityFree

1. Go to [InfinityFree](https://infinityfree.net/) and create a free account.
2. Verify your email address and log in.
3. Click on "New Account" to create a new hosting account.
4. Choose a subdomain for your website (e.g., grampanchayatchikhali.epizy.com) or connect your custom domain.
5. Wait for your hosting account to be activated (usually immediate).

## Step 2: Access Your Control Panel

1. From your InfinityFree dashboard, click on "Control Panel" for your hosting account.
2. This will take you to the cPanel interface for managing your website.

## Step 3: Upload Files Using File Manager

1. In cPanel, find and click on "File Manager".
2. Navigate to the "htdocs" or "public_html" folder - this is your website's root directory.
3. Click on "Upload" from the top menu.
4. Select all files from your local `/public_html` directory and upload them.
5. Make sure to maintain the folder structure (api folder, assets folder, etc.).

## Step 4: Upload Files Using FTP (Alternative Method)

If you prefer using FTP for uploading files:

1. In cPanel, find "FTP Accounts" and note your FTP details.
2. Use an FTP client like FileZilla or WinSCP.
3. Connect using the provided hostname, username, and password.
4. Navigate to the "htdocs" or "public_html" folder.
5. Upload all files from your local `/public_html` directory.
6. Maintain the folder structure during upload.

## Step 5: Setup Proper Permissions

1. After uploading, return to File Manager.
2. Select the `.htaccess` file, right-click and select "Permissions".
3. Set permissions to 644 (rw-r--r--).
4. For folders, set permissions to 755 (rwxr-xr-x).
5. For PHP files, set permissions to 644 (rw-r--r--).

## Step 6: Verify Your Website

1. Visit your website URL (e.g., grampanchayatchikhali.epizy.com).
2. Check that all pages load correctly.
3. Test the image slider functionality.
4. Verify API endpoints by accessing them directly (e.g., grampanchayatchikhali.epizy.com/api/notices.json).
5. Test the responsiveness by viewing on mobile devices.

## Troubleshooting

If you encounter issues:

1. **404 Errors**: Check if files are in the correct location and have proper permissions.
2. **API not working**: Ensure API endpoints have correct file extensions (.php/.json).
3. **Images not loading**: Verify paths in the HTML file and check image permissions.
4. **PHP errors**: Check InfinityFree's PHP version (should be PHP 7.4+) in cPanel.
5. **CORS issues**: Ensure the `.htaccess` file was uploaded and has correct permissions.

## Note

- InfinityFree provides free hosting with PHP support, but has certain limitations.
- The platform includes 1GB storage and unlimited bandwidth.
- In most cases, their PHP configuration is sufficient for running the static site with API endpoints.
- For advanced features or custom domains, you may need to consider their premium plan.