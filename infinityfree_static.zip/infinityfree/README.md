# InfinityFree Static Version for Gram Panchayat Chikhali

This directory contains a static version of the Gram Panchayat Chikhali website, designed to be hosted on InfinityFree (or any other PHP hosting service).

## Directory Structure

- `/public_html` - The main web directory that should be uploaded to the hosting service
  - `/api` - Contains JSON files and PHP endpoints to simulate the backend
  - `/assets` - Contains static assets like images
  - `index.html` - The main HTML file for the website

## Setup Instructions

1. Create an account on InfinityFree (https://infinityfree.net/)
2. Create a new website with a domain of your choice
3. Upload all contents of the `/public_html` directory to your hosting space
4. Access your website using the provided domain

## Features

- Responsive design that works on mobile and desktop
- Bilingual support (Hindi)
- Image slider with 7 images 
- Service links section with external links
- Notice board with dynamic loading of notices
- Projects and schemes sections
- Meeting calendar
- Contact information
- Login/Register functionality (simulated)

## Mock API Endpoints

The static version uses the following endpoints to simulate backend functionality:

- `/api/notices.json` - Returns notices data
- `/api/schemes.json` - Returns schemes data
- `/api/projects.json` - Returns projects data
- `/api/meetings.json` - Returns meetings data
- `/api/login.php` - Simulates login functionality
- `/api/register.php` - Simulates registration functionality
- `/api/user.php` - Returns user data
- `/api/logout.php` - Simulates logout functionality

## Notes

- This is a static version with mocked APIs for demonstration purposes
- The main dynamic version of the site is built with React.js and Node.js
- All form submissions are simulated and do not actually store data